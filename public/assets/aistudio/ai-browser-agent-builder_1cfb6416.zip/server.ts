import express from 'express';
import { createServer as createViteServer } from 'vite';
import { BrowserUse } from 'browser-use-sdk/v4';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json());

const client = new BrowserUse({
  apiKey: process.env.BROWSER_USE_API_KEY!,
});

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

async function createServer() {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);

  app.post('/api/browser/start', async (req, res) => {
    try {
      const browser = await client.browsers.create();
      res.json(browser);
    } catch (error) {
      res.status(500).json({ error: 'Failed to start browser' });
    }
  });

  app.post('/api/browser/:id/stop', async (req, res) => {
    try {
      await client.browsers.stop(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to stop browser' });
    }
  });

  app.post('/api/agent/task', async (req, res) => {
    const { task } = req.body;
    try {
      const run = await client.runs.create({ task });
      res.json(run);
    } catch (error) {
      res.status(500).json({ error: 'Failed to run task' });
    }
  });

  app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
  });
}

createServer();
