/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';

export default function App() {
  const [browser, setBrowser] = useState<any>(null);
  const [task, setTask] = useState('');

  const startBrowser = async () => {
    const res = await fetch('/api/browser/start', { method: 'POST' });
    setBrowser(await res.json());
  };

  const stopBrowser = async () => {
    if (browser) {
      await fetch(`/api/browser/${browser.id}/stop`, { method: 'POST' });
      setBrowser(null);
    }
  };

  const runTask = async () => {
    await fetch('/api/agent/task', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task }),
    });
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">AI Browser Agent Builder</h1>
      <div className="flex gap-4 mb-6">
        {!browser ? (
          <button onClick={startBrowser} className="bg-blue-500 text-white px-4 py-2 rounded">Start Cloud Browser</button>
        ) : (
          <button onClick={stopBrowser} className="bg-red-500 text-white px-4 py-2 rounded">Stop Browser</button>
        )}
      </div>
      {browser && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Live Browser Preview</h2>
          <iframe src={browser.previewUrl} className="w-full h-[500px] border" />
        </div>
      )}
      <div className="flex gap-2">
        <input 
          value={task} 
          onChange={(e) => setTask(e.target.value)} 
          className="border p-2 flex-grow rounded"
          placeholder="Enter agent task..." 
        />
        <button onClick={runTask} className="bg-green-500 text-white px-4 py-2 rounded">Run Task</button>
      </div>
    </div>
  );
}
